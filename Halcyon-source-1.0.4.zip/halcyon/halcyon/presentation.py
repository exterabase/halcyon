"""Shared presentation for the status commands."""

from pathlib import Path

from halcyon_tl.errors import (
    MediaCaptionTooLongError,
    MediaEmptyError,
    MediaInvalidError,
    MediaNewInvalidError,
    RPCError,
    SendMessageMediaInvalidError,
)
from halcyon_tl.types import InputMediaWebPage

NAME = "halcyon."
DEVELOPER_CONTACT = "@lyzos"
DEVELOPER_URL = "https://t.me/lyzos"
_ASSET_URL = "https://raw.githubusercontent.com/exterabase/halcyon/main/assets/"
_BANNER_NAME = "IMG_20261120_220327.png"
BANNER_URL = _ASSET_URL + _BANNER_NAME
_LEGACY_BANNER_URL = _ASSET_URL + "halcyon.jpeg"
_BANNER_PATH = Path(__file__).resolve().parents[1] / "assets" / _BANNER_NAME


def resolve_banner_url(value):
    url = str(value or "")
    return BANNER_URL if url == _LEGACY_BANNER_URL else url


def enable_rich_ui(db, modules):
    if db.get(__name__, "rich_ui_updated", False):
        return
    for module in modules:
        if type(module).__name__ in {"Help", "CoreMod", "LoaderMod"}:
            module.config["rich_mode"] = True
    db.set(__name__, "rich_ui_updated", True)


async def answer_status(message, text, config):
    from .inline.rich import media_html, rich_html, rich_rejected
    from .utils import answer, answer_with_media_fallback

    url = resolve_banner_url(config["banner_url"])
    reply_to = getattr(message, "reply_to_msg_id", None)
    client = getattr(message, "client", None)
    inline = getattr(getattr(client, "loader", None), "inline", None)
    if getattr(getattr(client, "halcyon_me", None), "premium", False) or getattr(inline, "init_complete", False):
        figure = media_html("photo", url) or ""
        body = rich_html(text)
        if figure:
            body = figure + body if config["invert_media"] else body + figure
        try:
            if result := await answer(message, text, rich_message=body, reply_to=reply_to):
                return result
        except RPCError as error:
            if not rich_rejected(error):
                raise
    if url == BANNER_URL and not config["quote_media"] and _BANNER_PATH.is_file():
        media = _BANNER_PATH
    elif url:
        media = InputMediaWebPage(url, force_large_media=not config["quote_media"], optional=True)
    else:
        media = None
    try:
        return await answer_with_media_fallback(
            message,
            text,
            file=media,
            link_preview=isinstance(media, InputMediaWebPage),
            invert_media=bool(media and config["invert_media"]),
            reply_to=reply_to,
        )
    except (
        MediaCaptionTooLongError,
        MediaEmptyError,
        MediaInvalidError,
        MediaNewInvalidError,
        SendMessageMediaInvalidError,
    ):
        if media is None:
            raise
        return await answer(message, text, link_preview=False, reply_to=reply_to)
