"""Translate the inline bot's existing content to Telegram Rich Messages."""

import copy
import re
from html import escape
from urllib.parse import urlsplit

from halcyon_tl.errors import BadRequestError
from halcyon_tl.extensions import html as legacy_html
from halcyon_tl.tl import types

from .._internal import normalize_rich_html


def rich_html(text):
    # The rich HTML parser collapses whitespace outside preformatted blocks.
    return re.sub(
        r"(<pre\b[^>]*>.*?</pre>)|\r\n?|\n",
        lambda match: match[1] or "<br>",
        normalize_rich_html(text or ""),
        flags=re.IGNORECASE | re.DOTALL,
    )


def media_html(kind, url):
    if not isinstance(url, str):
        return None
    try:
        parsed = urlsplit(url)
    except ValueError:
        return None
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return None
    src = escape(url, quote=True)
    if kind == "photo":
        return f'<figure><img src="{src}"/></figure>'
    tag = {
        "video": "video", "gif": "video", "audio": "audio", "voice": "audio",
        "file": "tg-document", "document": "tg-document",
    }.get(kind)
    return f'<figure><{tag} src="{src}"></{tag}></figure>' if tag else None


def _supported_button(button):
    kind = getattr(button, "type", None)
    if isinstance(kind, types.InlineButtonTypeCallback):
        if kind.requires_password or not 1 <= len(kind.data) <= 64:
            return False
        try:
            kind.data.decode("utf-8")
        except UnicodeDecodeError:
            return False
        return True
    return isinstance(kind, (
        types.InlineButtonTypeUrl, types.InlineButtonTypeSwitchInline,
        types.InlineButtonTypeCopy, types.InlineButtonTypeDisabled,
        types.InlineButtonTypeWebView, types.InlineButtonTypeUserProfile,
    ))


def embed_buttons(content, markup):
    if not isinstance(content, (types.InputRichMessageHTML, types.InputRichMessageMarkdown)):
        return content, markup
    if not isinstance(markup, types.ReplyInlineMarkup):
        return content, markup

    from ..utils.rich import button_row_html

    rows, remaining = [], []
    for row in markup.rows:
        if row.buttons and all(_supported_button(button) for button in row.buttons):
            rows.append(button_row_html(row.buttons))
        else:
            remaining.append(row)
    if not rows:
        return content, markup
    result = copy.copy(content)
    if isinstance(result, types.InputRichMessageHTML):
        result.html += "\n" + "\n".join(rows)
    else:
        result.markdown += "\n\n" + "\n\n".join(rows)
    return result, types.ReplyInlineMarkup(remaining) if remaining else None


def rich_inline_result(result):
    message = getattr(result, "send_message", None)
    if isinstance(message, types.InputBotInlineMessageRichMessage):
        content = message.rich_message
    elif isinstance(message, (
        types.InputBotInlineMessageText, types.InputBotInlineMessageMediaAuto,
    )):
        text = rich_html(legacy_html.unparse(message.message, message.entities or []))
        if isinstance(message, types.InputBotInlineMessageMediaAuto):
            media = media_html(getattr(result, "type", None), getattr(
                getattr(result, "content", None), "url", None,
            ))
            if media is None:
                return result
            text = media + text
        if not text:
            return result
        content = types.InputRichMessageHTML(html=text)
    else:
        return result

    content, markup = embed_buttons(content, message.reply_markup)
    if isinstance(message, types.InputBotInlineMessageRichMessage) and content is message.rich_message:
        return result
    converted = copy.copy(result)
    converted.send_message = types.InputBotInlineMessageRichMessage(content, reply_markup=markup)
    return converted


def rich_rejected(error):
    """Retry legacy rendering only when Telegram explicitly rejects the content."""
    if not isinstance(error, BadRequestError):
        return False
    return str(getattr(error, "message", "")).startswith((
        "RICH_", "BUTTON_", "MEDIA_", "PHOTO_", "EXTERNAL_MEDIA_", "ENTITY_", "RESULT_",
    )) or type(error).__name__.startswith((
        "RichMessage", "Button", "Media", "Photo", "WebpageMediaEmpty", "SendMessageMedia",
        "EntityBounds", "ResultType", "MessageTooLong",
    ))


def legacy_inline_result(result):
    message = getattr(result, "send_message", None)
    if not isinstance(message, types.InputBotInlineMessageRichMessage):
        return result
    if not isinstance(message.rich_message, types.InputRichMessageHTML):
        return result
    text, entities = legacy_html.parse(message.rich_message.html)
    fallback = copy.copy(result)
    fallback.send_message = types.InputBotInlineMessageText(
        text or "Halcyon", no_webpage=True, entities=entities,
        reply_markup=message.reply_markup,
    )
    return fallback
