"""Prompts and connection supervision for the Android launcher."""

import asyncio
import json
import os
import random
import sys

from halcyon_tl.tl.functions import PingRequest

from ._internal import register_secret


_launcher_input: asyncio.Queue | None = None


class TransportUnavailable(ConnectionError):
    """An active Telegram connection stopped answering."""


def emit(event, **fields):
    print("HALCYON_ANDROID " + json.dumps({"event": event, **fields}), flush=True)


async def ask(field, *, secret=False):
    emit("prompt", field=field)
    response = (
        await _launcher_input.get()
        if _launcher_input is not None
        else await asyncio.to_thread(sys.stdin.readline)
    )
    if not response:
        raise EOFError("Android launcher closed the login form")
    value = json.loads(response)
    if not isinstance(value, str):
        raise ValueError("Expected a text answer from the Android launcher")
    if secret:
        register_secret(value)
    return value


async def _race(primary, other):
    primary = asyncio.ensure_future(primary)
    other = asyncio.ensure_future(other)
    try:
        done, _ = await asyncio.wait((primary, other), return_when=asyncio.FIRST_COMPLETED)
        return await (primary if primary in done else other)
    finally:
        primary.cancel()
        other.cancel()
        await asyncio.gather(primary, other, return_exceptions=True)


async def run_with_launcher(entrypoint):
    """Deliver input to login prompts and stop when the launcher pipe closes."""
    global _launcher_input
    loop = asyncio.get_running_loop()
    queue = asyncio.Queue()
    closed = loop.create_future()
    fd = sys.stdin.fileno()
    remaining = b""

    def read_input():
        nonlocal remaining
        chunk = os.read(fd, 4096)
        if not chunk:
            loop.remove_reader(fd)
            if not closed.done():
                closed.set_result(None)
            return
        *lines, remaining = (remaining + chunk).split(b"\n")
        for line in lines:
            queue.put_nowait(line)

    async def heartbeat():
        while True:
            emit("heartbeat")
            await asyncio.sleep(10)

    loop.add_reader(fd, read_input)
    _launcher_input = queue
    pulse = asyncio.create_task(heartbeat())
    try:
        await _race(entrypoint(), closed)
    finally:
        pulse.cancel()
        await asyncio.gather(pulse, return_exceptions=True)
        loop.remove_reader(fd)
        _launcher_input = None


async def run_connected(account, inline=None, *, interval=20, timeout=10):
    """Recycle a stalled runtime after two unanswered Telegram pings."""
    clients = (account,) if inline is None else (account, inline)

    async def responsive(client):
        try:
            await asyncio.wait_for(client(PingRequest(random.getrandbits(63))), timeout)
        except (OSError, asyncio.TimeoutError):
            return False
        return True

    async def watch_transports():
        missed = 0
        while True:
            await asyncio.sleep(interval)
            if all(await asyncio.gather(*(responsive(client) for client in clients))):
                missed = 0
            else:
                missed += 1
                if missed >= 2:
                    raise TransportUnavailable("Telegram did not answer two connection checks")

    await _race(account.run_until_disconnected(), watch_transports())
