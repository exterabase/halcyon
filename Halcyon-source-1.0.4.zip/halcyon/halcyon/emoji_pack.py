"""Load and cache the document ID migration for the Halcyon emoji set."""

import asyncio
import json
import logging
import re
from pathlib import Path

from halcyon_tl.extensions.html import CUSTOM_EMOJI_ALIASES
from halcyon_tl.tl.functions.messages import GetStickerSetRequest
from halcyon_tl.tl.types import InputStickerSetShortName

from ._internal import private_write

PACK = "halcyon_pack"
logger = logging.getLogger(__name__)
_lock = asyncio.Lock()


def document_mapping(old_pack, new_pack):
    old = old_pack.documents
    new = new_pack.documents
    if not old or len(old) != len(new):
        raise ValueError("The source and Halcyon emoji packs have different lengths")
    return {before.id: after.id for before, after in zip(old, new)}


async def load(client, data_root):
    async with _lock:
        if CUSTOM_EMOJI_ALIASES:
            return

        cache = Path(data_root) / "emoji-pack.json"
        try:
            stored = json.loads(cache.read_text(encoding="utf-8"))
            mapping = {int(key): int(value) for key, value in stored.items()}
            if mapping and all(key > 0 and value > 0 for key, value in mapping.items()):
                CUSTOM_EMOJI_ALIASES.update(mapping)
                return
        except (OSError, TypeError, ValueError, AttributeError):
            pass

        readme = Path(__file__).resolve().parents[1] / "README.md"
        try:
            reference = re.search(
                r"\[Исходный набор для сопоставления\]\(https://t\.me/addemoji/(\w+)\)",
                readme.read_text(encoding="utf-8"),
            )
            if reference is None:
                raise ValueError("The source emoji set is missing from README.md")
            old_pack, new_pack = await asyncio.wait_for(asyncio.gather(*(
                client(GetStickerSetRequest(InputStickerSetShortName(name), 0))
                for name in (reference[1], PACK)
            )), timeout=12)
            mapping = document_mapping(old_pack, new_pack)
            CUSTOM_EMOJI_ALIASES.update(mapping)
            private_write(cache, json.dumps(mapping))
        except Exception as error:
            logger.warning("Could not load the Halcyon emoji pack (%s)", type(error).__name__)
