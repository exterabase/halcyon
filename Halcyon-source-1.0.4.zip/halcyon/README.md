# Halcyon

Based on [Heroku Userbot](https://github.com/coddrago/Heroku) (AGPL-3.0).

Разработчик Halcyon — [@lyzos](https://t.me/lyzos).

[Приложение для Android и сборка APK](android/README.md)

[Эмодзи-пак Halcyon](https://t.me/addemoji/halcyon_pack)

При первом входе Halcyon сопоставляет документы своего пака по порядку с исходным набором. Telegram хранит ID каждого эмодзи отдельно, поэтому изменение имени пака само по себе не меняет эмодзи в командах.

- [Исходный набор для сопоставления](https://t.me/addemoji/heroku_pack)
